﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            DataGridViewImageColumn imageColumn = new DataGridViewImageColumn();
            imageColumn.HeaderText = "picture";
            imageColumn.Name = "imageColumn";
            dataGridView1.Columns.Add(imageColumn);
            Image image = picture.png;
            DataGridViewRow row = new DataGridViewRow();
            row.CreateCells(dataGridView1);
            row.Cells[0].Value = image;
            dataGridView1.Rows.Add(row);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            try
            {
                // Подключение к базе данных
                DbConnection dbManager = new DbConnection("host=db.edu.cchgeu.ru; login=postgres; pass=postgres");

                string query = "SELECT * FROM public.\"Наименование продукции\"";
                RefreshData(query);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при подключении к базе данных: " + ex.Message);
            }
        }

        private void RefreshData(string query)
        {
            try
            {
                // Выполнение запроса к базе данных
                DbConnection dbManager = new DbConnection("host=db.edu.cchgeu.ru; login=postgres; pass=postgres");
                DataTable dt = new DataTable();
                dt = dbManager.ExecuteQuery(query);

                // Отображение данных на форме
                dataGridView.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при обновлении данных: " + ex.Message);
            }
        }


        private void sortingComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedSorting = sortingComboBox.SelectedItem.ToString();

            // Формирование запроса SELECT с сортировкой
            string query = "SELECT * FROM public.\"Product\" ORDER BY " + selectedSorting;

            RefreshData(query);
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Закрытие соединения перед закрытием формы
            connection.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
